# Agenda Cortinas e Persianas

App instalável (PWA) para organizar instalação, medição e ambientação. Os dados ficam
salvos no Supabase e sincronizam em tempo real entre todos os aparelhos da equipe.

## Como publicar no GitHub Pages (grátis, uns 5 minutos)

1. Crie uma conta no [GitHub](https://github.com) se ainda não tiver.
2. Clique em **New repository** (canto superior direito → "+" → "New repository").
   - Nome sugerido: `agenda-cortinas`
   - Marque como **Public**
   - Não marque "Add a README" (já temos um)
3. Na página do repositório recém-criado, clique em **uploading an existing file**
   (ou "Add file" → "Upload files").
4. Arraste todos os arquivos desta pasta (`index.html`, `app.js`, `manifest.json`,
   `sw.js`, a pasta `icons` inteira) e clique em **Commit changes**.
5. Vá em **Settings** (do repositório) → **Pages** no menu lateral.
6. Em "Build and deployment" → "Source", escolha **Deploy from a branch**.
7. Em "Branch", escolha `main` e a pasta `/ (root)`. Clique em **Save**.
8. Espere uns 1-2 minutos. O GitHub vai mostrar o link do site, algo como:
   `https://seu-usuario.github.io/agenda-cortinas/`

## Como instalar no celular

- **Android (Chrome)**: abra o link acima, vai aparecer um aviso "Instalar" no
  topo da tela — é só tocar. Ou toque nos três pontinhos → "Adicionar à tela inicial".
- **iPhone (Safari)**: abra o link, toque no ícone de compartilhar (o quadrado
  com a seta pra cima) → "Adicionar à Tela de Início".

Depois de instalado, o app abre em tela cheia, com ícone próprio, como qualquer
outro app do celular.

## Compartilhar com a equipe

Basta mandar o mesmo link (`https://seu-usuario.github.io/agenda-cortinas/`) para
quem mais for usar. Todo mundo que instalar vê e edita a mesma agenda — os dados
ficam no Supabase, não no celular de cada um.

## Sobre o banco de dados

O app usa uma tabela chamada `agendamentos` num projeto Supabase já existente
(`cortinas-app`), totalmente separada das outras tabelas do sistema. A chave usada
no código (`app.js`) é a chave pública ("publishable"), segura para ficar visível —
o controle de acesso real é feito pelas regras de segurança (RLS) no banco.

Não há tela de login: qualquer pessoa com o link do app consegue ver e editar os
agendamentos. Isso é intencional, para manter simples para a equipe. Se no futuro
quiser exigir login, é possível adicionar depois.

## Sobre notificações

O celular não recebe notificação automática sozinho a partir do app (isso exigiria
um servidor rodando push notifications, o que sai do escopo de um app gratuito
hospedado assim). Em vez disso, cada agendamento tem um botão de lembrete (🔔)
que baixa um arquivo `.ics` — importando esse arquivo no Google Agenda ou
Calendário do iPhone, o alarme de 1 hora antes é configurado ali, e quem manda a
notificação é o próprio sistema do celular.
