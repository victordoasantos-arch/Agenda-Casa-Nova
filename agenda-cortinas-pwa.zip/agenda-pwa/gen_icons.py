from PIL import Image, ImageDraw

def make_icon(size, path, maskable=False):
    img = Image.new("RGB", (size, size), "#20302E")
    draw = ImageDraw.Draw(img)
    pad = int(size * (0.22 if maskable else 0.14))
    inner = size - pad * 2

    # draped curtain motif: three vertical wave-folds in gold/ivory
    fold_w = inner / 3
    colors = ["#B8863E", "#E7DCC3", "#B8863E"]
    for i in range(3):
        x0 = pad + i * fold_w
        cx = x0 + fold_w / 2
        top_y = pad + inner * 0.06
        bot_y = pad + inner * 0.94
        amp = fold_w * 0.30
        pts = []
        steps = 24
        for s in range(steps + 1):
            t = s / steps
            y = top_y + (bot_y - top_y) * t
            import math
            x = cx + amp * math.sin(t * math.pi * 1.6 + i)
            pts.append((x, y))
        draw.line(pts, fill=colors[i], width=max(2, int(size * 0.045)))

    # rod at top
    rod_y = pad + inner * 0.02
    draw.line([(pad - inner*0.05, rod_y), (pad + inner*1.05, rod_y)], fill="#E7DCC3", width=max(2, int(size*0.03)))

    img.save(path)

make_icon(192, "/home/claude/agenda-pwa/icons/icon-192.png")
make_icon(512, "/home/claude/agenda-pwa/icons/icon-512.png")
make_icon(512, "/home/claude/agenda-pwa/icons/icon-maskable-512.png", maskable=True)
print("done")
